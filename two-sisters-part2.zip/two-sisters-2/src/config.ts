import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const TOTAL = 2027; // 67.57s
export const INK = '#222222';
export const FONT = loadFont('normal', {weights: ['500', '600', '700'], subsets: ['bengali', 'latin']}).fontFamily;
