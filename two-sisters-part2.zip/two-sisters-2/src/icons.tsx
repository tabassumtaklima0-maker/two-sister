import React from 'react';
import {INK, FONT} from './config';

const S = {stroke: INK, strokeWidth: 5, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
const Svg: React.FC<{size: number; vb?: string; children: React.ReactNode}> = ({size, vb = '0 0 200 200', children}) => (
  <svg width={size} height={size} viewBox={vb} style={{overflow: 'visible'}}>{children}</svg>
);

export const PinIcon: React.FC<{size?: number}> = ({size = 100}) => (
  <Svg size={size}>
    <path d="M100,185 C40,110 40,95 40,80 A60,60 0 1 1 160,80 C160,95 160,110 100,185Z" fill="#E94B4B" {...S} />
    <circle cx={100} cy={78} r={24} fill="#fff" {...S} />
  </Svg>
);
export const GarmentIcon: React.FC<{size?: number}> = ({size = 200}) => (
  <Svg size={size}>
    <path d="M60,30 Q100,60 140,30 L185,65 L158,100 L145,88 L145,175 L55,175 L55,88 L42,100 L15,65Z" fill="#FF7F9E" {...S} />
    <circle cx={100} cy={100} r={5} fill={INK} /><circle cx={100} cy={125} r={5} fill={INK} /><circle cx={100} cy={150} r={5} fill={INK} />
  </Svg>
);
export const ClockIcon: React.FC<{size?: number; hourDeg?: number; minDeg?: number}> = ({size = 240, hourDeg = 0, minDeg = 0}) => (
  <Svg size={size}>
    <circle cx={100} cy={100} r={88} fill="#fff" {...S} />
    {Array.from({length: 12}).map((_, i) => (
      <line key={i} x1={100} y1={22} x2={100} y2={32} transform={`rotate(${i * 30} 100 100)`} stroke={INK} strokeWidth={5} strokeLinecap="round" />
    ))}
    <line x1={100} y1={100} x2={100} y2={54} transform={`rotate(${hourDeg} 100 100)`} stroke={INK} strokeWidth={9} strokeLinecap="round" />
    <line x1={100} y1={100} x2={100} y2={36} transform={`rotate(${minDeg} 100 100)`} stroke={INK} strokeWidth={6} strokeLinecap="round" />
    <circle cx={100} cy={100} r={8} fill="#E94B4B" stroke={INK} strokeWidth={3} />
  </Svg>
);
export const SunIcon: React.FC<{size?: number}> = ({size = 90}) => (
  <Svg size={size}>
    {Array.from({length: 8}).map((_, i) => (
      <line key={i} x1={100} y1={14} x2={100} y2={40} transform={`rotate(${i * 45} 100 100)`} stroke={INK} strokeWidth={9} strokeLinecap="round" />
    ))}
    <circle cx={100} cy={100} r={44} fill="#FFC93C" {...S} />
  </Svg>
);
export const MoonIcon: React.FC<{size?: number}> = ({size = 90}) => (
  <Svg size={size}>
    <path d="M130,25 A76,76 0 1 0 175,140 A58,58 0 0 1 130,25Z" fill="#FFE08A" {...S} />
  </Svg>
);
export const PlateIcon: React.FC<{size?: number; food?: boolean}> = ({size = 200, food = true}) => (
  <Svg size={size}>
    <ellipse cx={100} cy={125} rx={88} ry={46} fill="#fff" {...S} />
    <ellipse cx={100} cy={122} rx={62} ry={30} fill="#EDEDED" stroke={INK} strokeWidth={3} />
    {food && (
      <>
        <path d="M55,118 Q100,50 145,118 Q100,138 55,118Z" fill="#FFFDF4" {...S} />
        <ellipse cx={132} cy={120} rx={20} ry={11} fill="#E8873A" stroke={INK} strokeWidth={3} />
      </>
    )}
  </Svg>
);
export const CheckIcon: React.FC<{size?: number}> = ({size = 100}) => (
  <Svg size={size}>
    <circle cx={100} cy={100} r={85} fill="#3DBE6B" {...S} />
    <path d="M58,104 L88,134 L142,70" fill="none" stroke="#fff" strokeWidth={17} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
export const DressIcon: React.FC<{size?: number; color?: string; patch?: boolean; sparkle?: boolean}> = ({size = 220, color = '#F4A6C8', patch = false, sparkle = false}) => (
  <Svg size={size}>
    <path d="M78,25 L92,60 L108,60 L122,25 L140,35 L132,85 L178,178 L22,178 L68,85 L60,35 Z" fill={color} {...S} />
    <path d="M70,98 H130" stroke={INK} strokeWidth={4} />
    {patch && <rect x={110} y={128} width={34} height={30} fill="#A5C8E8" stroke={INK} strokeWidth={3} strokeDasharray="6 5" transform="rotate(8 127 143)" />}
    {sparkle && [[30, 40], [170, 30], [180, 120]].map(([x, y], i) => (
      <path key={i} d={`M${x},${y - 16} L${x + 5},${y - 5} L${x + 16},${y} L${x + 5},${y + 5} L${x},${y + 16} L${x - 5},${y + 5} L${x - 16},${y} L${x - 5},${y - 5}Z`} fill="#FFD43B" stroke={INK} strokeWidth={3} />
    ))}
  </Svg>
);
export const WalletIcon: React.FC<{size?: number}> = ({size = 220}) => (
  <Svg size={size}>
    <path d="M25,60 H165 a15,15 0 0 1 15,15 V150 a15,15 0 0 1 -15,15 H35 a15,15 0 0 1 -15,-15 V65Z" fill="#A9683A" {...S} />
    <path d="M25,60 L130,30 L150,60Z" fill="#C98550" {...S} />
    <circle cx={158} cy={112} r={14} fill="#F4C542" stroke={INK} strokeWidth={4} />
    <circle cx={85} cy={115} r={26} fill="none" stroke="#fff" strokeWidth={4} strokeDasharray="6 6" />
    <path d="M72,102 L98,128 M98,102 L72,128" stroke="#E94B4B" strokeWidth={7} strokeLinecap="round" />
  </Svg>
);
export const CalendarIcon: React.FC<{size?: number}> = ({size = 220}) => (
  <Svg size={size}>
    <rect x={28} y={36} width={144} height={138} rx={14} fill="#fff" {...S} />
    <path d="M28,50 a14,14 0 0 1 14,-14 H158 a14,14 0 0 1 14,14 V76 H28Z" fill="#E94B4B" {...S} />
    <path d="M65,22 V48 M135,22 V48" stroke={INK} strokeWidth={8} strokeLinecap="round" />
    {[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={48 + c * 38} y={92 + r * 25} width={22} height={14} rx={3} fill="#C9D3E6" />))}
    <circle cx={124} cy={134} r={17} fill="none" stroke="#E94B4B" strokeWidth={6} />
  </Svg>
);
export const BrokenHeart: React.FC<{size?: number}> = ({size = 220}) => (
  <Svg size={size}>
    <path d="M100,175 C20,110 20,45 70,40 C90,38 100,55 100,65 L88,90 L108,110 L92,135 L104,155Z" fill="#E94B6A" {...S} />
    <g transform="translate(10,6) rotate(7 130 110)">
      <path d="M100,65 C100,55 110,38 130,40 C180,45 180,110 100,175 L104,155 L92,135 L108,110 L88,90Z" fill="#E94B6A" {...S} />
    </g>
  </Svg>
);
export const BookIcon: React.FC<{size?: number}> = ({size = 70}) => (
  <Svg size={size}>
    <path d="M20,50 Q60,35 100,55 Q140,35 180,50 V160 Q140,145 100,165 Q60,145 20,160Z" fill="#5B8DEF" {...S} />
    <path d="M100,55 V165" stroke={INK} strokeWidth={4} />
  </Svg>
);
export const HeartIcon: React.FC<{size?: number}> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M100,175 C20,110 20,45 70,40 C90,38 100,55 100,65 C100,55 110,38 130,40 C180,45 180,110 100,175Z" fill="#FF5C7A" {...S} />
  </Svg>
);
export const QuestionIcon: React.FC<{size?: number}> = ({size = 200}) => (
  <Svg size={size}>
    <circle cx={100} cy={100} r={88} fill="#FFD43B" {...S} />
    <text x={100} y={145} textAnchor="middle" fontSize={130} fontWeight={700} fill={INK} fontFamily={FONT}>?</text>
  </Svg>
);
export const ArrowIcon: React.FC<{size?: number}> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M20,100 H150 M110,55 L160,100 L110,145" fill="none" stroke={INK} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
/** Envelope artwork in a 220x160 box (use inside <svg>). */
export const EnvelopeG: React.FC = () => (
  <g>
    <rect x={10} y={10} width={200} height={140} rx={10} fill="#fff" stroke={INK} strokeWidth={5} />
    <path d="M10,12 L110,92 L210,12Z" fill="#F1F1F1" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    <path d="M12,148 L88,80 M208,148 L132,80" stroke={INK} strokeWidth={3} fill="none" />
  </g>
);
export const EnvelopeIcon: React.FC<{size?: number; glow?: boolean}> = ({size = 220, glow = false}) => (
  <svg width={size} height={(size * 160) / 220} viewBox="0 0 220 160" style={{overflow: 'visible', filter: glow ? 'drop-shadow(0 0 22px #FFF3A0)' : undefined}}>
    <EnvelopeG />
  </svg>
);

export const CrossX: React.FC<{size?: number}> = ({size = 200}) => (
  <Svg size={size}>
    <path d="M30,30 L170,170 M170,30 L30,170" stroke="#E53935" strokeWidth={26} strokeLinecap="round" />
  </Svg>
);
export const ShopIcon: React.FC<{size?: number}> = ({size = 200}) => (
  <Svg size={size}>
    <rect x={30} y={90} width={140} height={90} fill="#FFE3B0" {...S} />
    <path d="M15,90 L35,35 H165 L185,90Z" fill="#E94B4B" {...S} />
    {[0, 1, 2, 3].map((i) => <path key={i} d={`M${15 + i * 43},90 a21,18 0 0 0 43,0`} fill={i % 2 ? '#fff' : '#E94B4B'} {...S} />)}
    <rect x={80} y={120} width={40} height={60} fill="#7A4B2A" {...S} />
  </Svg>
);
export const CloudRainIcon: React.FC<{size?: number}> = ({size = 200}) => (
  <Svg size={size}>
    <path d="M55,120 A38,38 0 0 1 65,48 A52,52 0 0 1 160,62 A36,36 0 0 1 150,120Z" fill="#B9C9E0" {...S} />
    {[70, 100, 130].map((x) => <path key={x} d={`M${x},138 l-10,34`} stroke="#3B82F6" strokeWidth={9} strokeLinecap="round" />)}
  </Svg>
);
export const PlusIcon: React.FC<{size?: number}> = ({size = 60}) => (
  <Svg size={size}>
    <path d="M100,30 V170 M30,100 H170" stroke="#fff" strokeWidth={28} strokeLinecap="round" />
  </Svg>
);
export const PaperG: React.FC<{lines?: number}> = ({lines = 3}) => (
  <g>
    <rect x={0} y={0} width={200} height={130} rx={6} fill="#FFFDF4" stroke={INK} strokeWidth={4} />
    {Array.from({length: lines}).map((_, i) => <path key={i} d={`M20,${34 + i * 28} H${i === lines - 1 ? 120 : 180}`} stroke="#3B5BA9" strokeWidth={5} strokeLinecap="round" />)}
  </g>
);
