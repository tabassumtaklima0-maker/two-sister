import React from 'react';
import {useCurrentFrame} from 'remotion';
import {INK} from './config';
import {EnvelopeG} from './icons';

export type Expr = 'neutral' | 'angry' | 'sad' | 'cry' | 'shock' | 'tired' | 'smile' | 'worry' | 'happycry';
export type Pose = 'down' | 'hips' | 'cover' | 'hold' | 'pointR' | 'talk' | 'up' | 'lap' | 'hugR' | 'hugL';
// [leftUpper, leftFore, rightUpper, rightFore] rotation (deg)
const POSES: Record<Pose, [number, number, number, number]> = {
  down: [8, 5, -8, -5],
  hips: [40, -87, -40, 87],
  cover: [140, 110, -140, -110],
  hold: [-5, -100, 5, 100],
  pointR: [8, 5, -70, -20],
  talk: [8, 5, -50, -70],
  up: [150, 15, -150, -15],
  lap: [-12, -10, 12, 10],
  hugR: [-40, -50, -80, -10],
  hugL: [80, 10, 40, 50],
};
const BROW: Record<Expr, string> = {
  neutral: 'M130,108 Q158,98 188,108', smile: 'M130,106 Q158,94 188,106', angry: 'M128,94 L190,120',
  sad: 'M128,118 L190,96', cry: 'M128,118 L190,96', worry: 'M128,116 L190,100',
  shock: 'M130,88 Q158,70 188,88', happycry: 'M128,116 L190,98', tired: 'M130,114 Q158,108 188,112',
};
const MOUTH: Record<Expr, string> = {
  neutral: 'M182,210 L218,210', smile: 'M172,200 Q200,226 228,200', angry: 'M178,214 Q200,202 222,214',
  sad: 'M178,216 Q200,198 222,216', cry: 'M178,216 Q200,198 222,216', worry: 'M180,214 Q200,204 220,214',
  shock: '', happycry: 'M172,200 Q200,226 228,200', tired: 'M180,206 Q200,218 220,206',
};

const Arm: React.FC<{x: number; a1: number; a2: number; up: string; skin: string; packet?: boolean}> = ({x, a1, a2, up, skin, packet}) => (
  <g transform={`translate(${x},300) rotate(${a1})`}>
    <rect x={-17} y={-6} width={34} height={102} rx={17} fill={up} stroke={INK} strokeWidth={3} />
    <g transform={`translate(0,90) rotate(${a2})`}>
      <rect x={-15} y={-6} width={30} height={96} rx={15} fill={skin} stroke={INK} strokeWidth={3} />
      <circle cx={0} cy={92} r={19} fill={skin} stroke={INK} strokeWidth={3} />
      {packet && (
        <g>
          <rect x={-34} y={92} width={68} height={86} rx={8} fill="#2F6FED" stroke={INK} strokeWidth={3} />
          <path d="M-34,116 H34" stroke="#fff" strokeWidth={4} />
        </g>
      )}
    </g>
  </g>
);

export interface CharProps {
  who: 'nusrat' | 'tania';
  cx: number; // horizontal center on screen
  foot: number; // y of the feet on screen
  size?: number; // rendered height in px
  expr?: Expr;
  mouth?: 0 | 1 | 2;
  pose?: Pose;
  sit?: boolean;
  tilt?: number;
  tremble?: boolean;
  eyesClosed?: boolean;
  envelope?: boolean;
  bounce?: boolean;
  walk?: number;
  packet?: boolean;
}

export const Character: React.FC<CharProps> = ({who, cx, foot, size = 760, expr = 'neutral', mouth = 0, pose = 'down', sit = false, tilt = 0, tremble = false, eyesClosed = false, envelope = false, bounce = false, walk = 0, packet = false}) => {
  const f = useCurrentFrame();
  const n = who === 'nusrat';
  const SKIN = n ? '#E6B488' : '#F2C69E';
  const HAIR = '#2A1A16';
  const w = (size * 640) / 760;
  const bob = Math.sin(f / 14) * 7 - (bounce ? Math.abs(Math.sin(f / 6)) * 14 : 0);
  const jx = tremble ? Math.sin(f * 2.9) * 5 : 0;
  const blink = eyesClosed || (f + (n ? 0 : 37)) % 96 < 4 ? 0.08 : 1;
  const sw = walk ? Math.sin(f * walk) : 0;
  const [pl1, l2, pr1, r2base] = POSES[pose];
  const l1 = pl1 - sw * 22;
  const r1 = pr1 + sw * 22;
  const r2 = pose === 'talk' && mouth ? r2base + Math.sin(f * 0.5) * 12 : r2base;
  const tr = tremble ? Math.sin(f * 3.3) * 3 : 0;

  const rx = n ? 23 : 28;
  const ry = (n ? 29 : 35) * (expr === 'shock' ? 1.15 : expr === 'angry' ? 0.62 : 1);
  const lookY = ['sad', 'cry', 'tired', 'worry'].includes(expr) ? 7 : 0;
  const pr = expr === 'shock' ? 6 : 11;
  const mouthOpen = mouth > 0 || expr === 'shock';

  return (
    <svg width={w} height={size} viewBox="-120 0 640 760" style={{position: 'absolute', left: cx - w / 2, top: foot - (size * 715) / 760, overflow: 'visible'}}>
      <g transform={`translate(${jx},${bob})`}>
        {n && <ellipse cx={200} cy={150} rx={100} ry={112} fill={HAIR} stroke={INK} strokeWidth={3} />}
        {!n && (
          <>
            <circle cx={116} cy={64} r={38} fill={HAIR} stroke={INK} strokeWidth={3} />
            <circle cx={284} cy={64} r={38} fill={HAIR} stroke={INK} strokeWidth={3} />
          </>
        )}

        {/* legs */}
        {!sit && n && (
          <>
            <g transform={`rotate(${sw * 16} 172 520)`}>
              <rect x={148} y={520} width={48} height={190} rx={22} fill="#EBD9A8" stroke={INK} strokeWidth={3} />
              <ellipse cx={172} cy={712} rx={34} ry={14} fill="#8A5A3C" stroke={INK} strokeWidth={3} />
            </g>
            <g transform={`rotate(${-sw * 16} 228 520)`}>
              <rect x={204} y={520} width={48} height={190} rx={22} fill="#EBD9A8" stroke={INK} strokeWidth={3} />
              <ellipse cx={228} cy={712} rx={34} ry={14} fill="#8A5A3C" stroke={INK} strokeWidth={3} />
            </g>
          </>
        )}
        {!sit && !n && (
          <>
            <g transform={`rotate(${sw * 16} 170 500)`}>
              <rect x={150} y={500} width={42} height={190} rx={20} fill={SKIN} stroke={INK} strokeWidth={3} />
              <rect x={148} y={636} width={46} height={64} rx={14} fill="#fff" stroke={INK} strokeWidth={3} />
              <ellipse cx={170} cy={708} rx={36} ry={15} fill="#222" />
            </g>
            <g transform={`rotate(${-sw * 16} 230 500)`}>
              <rect x={208} y={500} width={42} height={190} rx={20} fill={SKIN} stroke={INK} strokeWidth={3} />
              <rect x={206} y={636} width={46} height={64} rx={14} fill="#fff" stroke={INK} strokeWidth={3} />
              <ellipse cx={230} cy={708} rx={36} ry={15} fill="#222" />
            </g>
          </>
        )}

        {/* neck + body */}
        <rect x={184} y={235} width={32} height={36} rx={10} fill={SKIN} stroke={INK} strokeWidth={3} />
        {n ? (
          <>
            <rect x={122} y={255} width={156} height={315} rx={52} fill="#3E9C9A" stroke={INK} strokeWidth={3} />
            <path d="M172,258 L200,300 L228,258 Z" fill={SKIN} stroke={INK} strokeWidth={3} strokeLinejoin="round" />
            <path d="M150,345 H250" stroke="#F5E6B8" strokeWidth={5} strokeDasharray="2 12" strokeLinecap="round" />
            <path d="M126,546 H274" stroke="#F5E6B8" strokeWidth={6} />
            <path d="M128,268 Q200,345 276,332 L276,368 Q190,372 124,296 Z" fill="#F2B8C6" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
          </>
        ) : (
          <>
            <rect x={128} y={258} width={144} height={200} rx={44} fill="#fff" stroke={INK} strokeWidth={3} />
            <path d="M126,400 L274,400 L296,530 L104,530 Z" fill="#2B4A9B" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
            <path d="M160,410 L150,525 M200,410 L200,525 M240,410 L250,525" stroke="#1F3779" strokeWidth={3} />
            <path d="M166,256 L198,296 L170,302 Z M234,256 L202,296 L230,302 Z" fill="#fff" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
            <path d="M192,298 L208,298 L212,350 L200,364 L188,350 Z" fill="#D64545" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
          </>
        )}
        {sit && n && (
          <>
            <rect x={100} y={540} width={200} height={76} rx={38} fill="#EBD9A8" stroke={INK} strokeWidth={3} />
            <path d="M140,588 Q200,560 260,588" fill="none" stroke={INK} strokeWidth={3} />
            <ellipse cx={122} cy={600} rx={20} ry={12} fill={SKIN} stroke={INK} strokeWidth={3} />
            <ellipse cx={278} cy={600} rx={20} ry={12} fill={SKIN} stroke={INK} strokeWidth={3} />
          </>
        )}
        {n && (
          <>
            {[0, 1, 2, 3, 4].map((i) => (
              <ellipse key={i} cx={292 + (i % 2 ? 6 : -4)} cy={262 + i * 52} rx={25} ry={30} fill={HAIR} stroke={INK} strokeWidth={3} />
            ))}
            <ellipse cx={290} cy={526} rx={14} ry={10} fill="#D9534F" stroke={INK} strokeWidth={3} />
          </>
        )}

        {/* head group */}
        <g transform={`rotate(${tilt + tr} 200 250)`}>
          <circle cx={110} cy={160} r={15} fill={SKIN} stroke={INK} strokeWidth={3} />
          <circle cx={290} cy={160} r={15} fill={SKIN} stroke={INK} strokeWidth={3} />
          <ellipse cx={200} cy={150} rx={90} ry={98} fill={SKIN} stroke={INK} strokeWidth={3} />
          {n ? (
            <path d="M108,150 Q104,50 200,46 Q296,50 292,150 Q276,98 210,96 Q196,118 150,120 Q122,126 108,150 Z" fill={HAIR} stroke={INK} strokeWidth={3} strokeLinejoin="round" />
          ) : (
            <>
              <path d="M106,150 Q100,48 200,44 Q300,48 294,150 Q284,96 200,92 Q116,96 106,150 Z" fill={HAIR} stroke={INK} strokeWidth={3} strokeLinejoin="round" />
              <circle cx={134} cy={86} r={10} fill="#E4572E" stroke={INK} strokeWidth={3} />
              <circle cx={266} cy={86} r={10} fill="#E4572E" stroke={INK} strokeWidth={3} />
            </>
          )}
          <ellipse cx={138} cy={192} rx={20} ry={11} fill="#F28C82" opacity={n ? 0.3 : 0.6} />
          <ellipse cx={262} cy={192} rx={20} ry={11} fill="#F28C82" opacity={n ? 0.3 : 0.6} />
          <path d="M200,172 q5,10 -3,14" fill="none" stroke={INK} strokeWidth={3} strokeLinecap="round" />
          {[160, 240].map((ex) => (
            <g key={ex}>
              <g transform={`translate(${ex},150) scale(1,${blink}) translate(${-ex},-150)`}>
                <ellipse cx={ex} cy={150} rx={rx} ry={ry} fill="#fff" stroke={INK} strokeWidth={3} />
                <circle cx={ex} cy={150 + lookY} r={pr} fill="#1b1b1b" />
                <circle cx={ex + 4} cy={146 + lookY} r={3} fill="#fff" />
                {expr === 'tired' && <path d={`M${ex - rx},150 A${rx},${ry} 0 0 1 ${ex + rx},150 Z`} fill={SKIN} stroke={INK} strokeWidth={3} />}
              </g>
              {expr === 'tired' && <ellipse cx={ex} cy={192} rx={22} ry={7} fill="#7a4a5a" opacity={0.28} />}
            </g>
          ))}
          <path d={BROW[expr]} fill="none" stroke={INK} strokeWidth={6} strokeLinecap="round" />
          <path d={BROW[expr]} fill="none" stroke={INK} strokeWidth={6} strokeLinecap="round" transform="translate(400,0) scale(-1,1)" />
          {mouthOpen ? (
            <>
              <ellipse cx={200} cy={214} rx={expr === 'shock' ? 15 : mouth === 1 ? 15 : 24} ry={expr === 'shock' ? 22 : mouth === 1 ? 10 : 22} fill="#8B2635" stroke={INK} strokeWidth={3} />
              {mouth === 2 && <ellipse cx={200} cy={228} rx={14} ry={8} fill="#E5707E" />}
            </>
          ) : (
            <path d={MOUTH[expr]} fill="none" stroke={INK} strokeWidth={4} strokeLinecap="round" />
          )}
          {(expr === 'cry' || expr === 'happycry') &&
            [160, 240].map((ex, i) =>
              [0, 0.5].map((o) => {
                const p = (f * 0.035 + o + i * 0.2) % 1;
                return <ellipse key={`${i}-${o}`} cx={ex + (i ? 6 : -6)} cy={178 + p * 120} rx={7} ry={10} fill="#7CC6F5" stroke="#3b8fc4" strokeWidth={1.5} opacity={1 - p * p} />;
              }),
            )}
        </g>

        {/* arms */}
        <Arm x={122} a1={l1} a2={l2} up={n ? '#3E9C9A' : '#fff'} skin={SKIN} />
        <Arm x={278} a1={r1} a2={r2} up={n ? '#3E9C9A' : '#fff'} skin={SKIN} packet={packet} />
        {envelope && (
          <g transform="translate(200,372) scale(0.5) translate(-110,-80)">
            <EnvelopeG />
          </g>
        )}
      </g>
    </svg>
  );
};
