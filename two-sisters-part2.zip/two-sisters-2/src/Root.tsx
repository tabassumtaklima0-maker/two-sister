import React from 'react';
import {Composition} from 'remotion';
import {TwoSistersPart2} from './Video';
import {FPS, W, H, TOTAL} from './config';

export const RemotionRoot: React.FC = () => (
  <Composition id="TwoSistersPart2" component={TwoSistersPart2} durationInFrames={TOTAL} fps={FPS} width={W} height={H} />
);
