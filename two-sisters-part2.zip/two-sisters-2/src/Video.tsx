import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {Scene} from './ui';
import {TOTAL, FPS} from './config';
import {S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12} from './Scenes';

export const TwoSistersPart2: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    <Audio src={staticFile('voice.mp3')} />
    <Scene from={0} to={5.8}><S1 /></Scene>
    <Scene from={5.8} to={16.85}><S2 /></Scene>
    <Scene from={16.85} to={23.66}><S3 /></Scene>
    <Scene from={23.66} to={26.2}><S4 /></Scene>
    <Scene from={26.2} to={32.56}><S5 /></Scene>
    <Scene from={32.56} to={35.3}><S6 /></Scene>
    <Scene from={35.3} to={39.7}><S7 /></Scene>
    <Scene from={39.7} to={45.34}><S8 /></Scene>
    <Scene from={45.34} to={52.46}><S9 /></Scene>
    <Scene from={52.46} to={57.0}><S10 /></Scene>
    <Scene from={57.0} to={63.1}><S11 /></Scene>
    <Scene from={63.1} to={TOTAL / FPS}><S12 /></Scene>
  </AbsoluteFill>
);
