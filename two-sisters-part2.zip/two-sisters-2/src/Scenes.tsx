import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {FONT, INK, TOTAL} from './config';
import {Character} from './Character';
import {MGBG, RoomBG, StreetBG, Rain, Extra, Door, ParentsFrame, Vignette} from './Backgrounds';
import {Pop, Pill, Card, SpeechBubble, Caption, Shake, Zoom, Fill, useT, useMouth} from './ui';
import {PaperG, ShopIcon, DressIcon, HeartIcon, CloudRainIcon, CrossX, WalletIcon, CheckIcon, PlusIcon} from './icons';

const L = (t: number, a: [number, number], b: [number, number]) => interpolate(t, a, b, {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
const T: React.CSSProperties = {fontFamily: FONT, fontWeight: 700, color: INK};

const Paper: React.FC<{w: number}> = ({w}) => (
  <svg width={w} height={(w * 130) / 200} viewBox="0 0 200 130" style={{overflow: 'visible'}}><PaperG lines={3} /></svg>
);

const CROWD = [
  {x0: 100, dir: 1, sp: 2.2, foot: 1470, size: 520, color: '#8E6BBF', hair: '#222'},
  {x0: 520, dir: -1, sp: 1.8, foot: 1450, size: 500, color: '#E0883E', hair: '#4A2C1A'},
  {x0: 900, dir: 1, sp: 1.5, foot: 1490, size: 540, color: '#3E9C9A', hair: '#111'},
  {x0: 300, dir: -1, sp: 2.4, foot: 1420, size: 470, color: '#C9444E', hair: '#222'},
];
const UMB = ['#E94B4B', '#3B82F6', '#FFD43B', '#2E8F8C'];
const Crowd: React.FC<{umb?: boolean}> = ({umb = false}) => {
  const f = useCurrentFrame();
  return (
    <>
      {CROWD.map((c, i) => {
        const x = ((((c.x0 + c.dir * f * c.sp) % 1400) + 1400) % 1400) - 160;
        return <Extra key={i} cx={x} foot={c.foot} size={c.size} color={c.color} hair={c.hair} walk={0.2} umbrella={umb ? UMB[i] : undefined} />;
      })}
    </>
  );
};

// ---------- S1: Tania opens the envelope ----------
export const S1: React.FC = () => {
  const t = useT();
  return (
    <>
      <RoomBG mode="morning" window />
      <Character who="tania" cx={540} foot={1780} size={1000} expr="worry" pose="hold" envelope tremble={t < 2.1} />
      <Pop cx={540} y={1170} at={4.0} float={5}><Paper w={300} /></Pop>
      <Caption />
    </>
  );
};

// ---------- S2: the letter (motion graphics) ----------
const LETTER = [
  {t: 'তানিয়া,', at: 5.88},
  {t: 'রাগ করিস না।', at: 7.24},
  {t: 'তোর রাগ ভাঙানোর জন্য চিঠিটা লিখে গেলাম।', at: 8.96},
  {t: 'আমি বাজারে গেছি, তোর পছন্দের নীল জামাটা আনতে।', at: 12.54},
];
export const S2: React.FC = () => {
  const t = useT();
  const rise = 1 - L(t, [5.8, 6.3], [0, 1]);
  return (
    <>
      <MGBG />
      <div style={{position: 'absolute', left: 100, top: 150, width: 880, height: 1160, background: '#FFFDF4', border: `6px solid ${INK}`, borderRadius: 18, boxShadow: '0 16px 0 rgba(0,0,0,.18)', transform: `translateY(${rise * 300}px) rotate(-1.5deg)`, backgroundImage: 'repeating-linear-gradient(transparent 0, transparent 107px, #C9D6EE 107px, #C9D6EE 110px)', backgroundPosition: '0 70px', padding: '60px 64px', boxSizing: 'border-box'}}>
        {LETTER.map((l, i) => (
          <div key={i} style={{...T, color: '#1F3A6B', fontSize: 68, lineHeight: '110px', opacity: L(t, [l.at, l.at + 0.3], [0, 1]), transform: `translateY(${L(t, [l.at, l.at + 0.3], [16, 0])}px)`}}>{l.t}</div>
        ))}
      </div>
      <Pop cx={300} y={1400} at={12.76} float={6}><ShopIcon size={300} /></Pop>
      <Pop cx={780} y={1400} at={15.1} float={6}><DressIcon size={300} color="#4F8DF7" sparkle /></Pop>
    </>
  );
};

// ---------- S3: Tania feels guilty ----------
export const S3: React.FC = () => {
  const m = useMouth('tania');
  return (
    <>
      <Zoom a={1} b={1.05}>
        <RoomBG mode="morning" />
        <Character who="tania" cx={540} foot={1868} size={1100} expr="cry" mouth={m} pose="hold" tremble />
        <Pop cx={540} y={1270} at={16.85}><Paper w={360} /></Pop>
      </Zoom>
      <SpeechBubble left={90} top={150} width={900} tailX={540} size={62} lines={[{text: 'আপু... আমি আপুকে কত বকলাম।', at: 16.88}, {text: 'আপু তো আমার জন্য কত কষ্ট করে...', at: 20.8}]} />
      <Pop cx={880} y={700} at={21.4} float={8}><HeartIcon size={150} /></Pop>
    </>
  );
};

// ---------- S4: Tania runs out ----------
export const S4: React.FC = () => {
  const t = useT();
  return (
    <>
      <RoomBG mode="morning" shelf />
      <Door x={780} y={740} />
      <Character who="tania" cx={L(t, [23.66, 26.15], [120, 1300])} foot={1560} size={760} expr="worry" walk={0.8} bounce />
      <Caption />
    </>
  );
};

// ---------- S5: bazaar street, Nusrat walks away ----------
export const S5: React.FC = () => {
  const t = useT();
  return (
    <>
      <StreetBG dark={L(t, [26.2, 32.5], [0.05, 0.3])} />
      <Crowd />
      <Character who="nusrat" cx={L(t, [26.2, 32.5], [800, 580])} foot={1500} size={560} expr="tired" walk={0.18} packet={t >= 30.3} />
      <Character who="tania" cx={230} foot={1830} size={900} expr="worry" />
      <Caption />
    </>
  );
};

// ---------- S6: Tania shouts, rain begins ----------
export const S6: React.FC = () => {
  const t = useT();
  const m = useMouth('tania');
  return (
    <>
      <StreetBG dark={0.35} />
      <Crowd />
      <Character who="nusrat" cx={L(t, [32.5, 35.3], [820, 900])} foot={1480} size={480} expr="tired" walk={0.18} packet />
      <Character who="tania" cx={330} foot={1850} size={1000} expr="cry" mouth={m} pose="talk" tremble />
      <Rain intensity={L(t, [32.5, 35.3], [0.1, 0.4])} />
      <SpeechBubble left={90} top={150} width={900} tailX={330} size={72} lines={[{text: 'আপু! আপু!', at: 32.66}, {text: 'দাঁড়াও!', at: 34.32}]} />
    </>
  );
};

// ---------- S7: Nusrat turns, shocked ----------
export const S7: React.FC = () => {
  const m = useMouth('nusrat');
  return (
    <>
      <StreetBG dark={0.5} />
      <Crowd umb />
      <Character who="nusrat" cx={540} foot={1850} size={1000} expr="shock" mouth={m} packet />
      <Rain intensity={0.7} />
      <SpeechBubble left={90} top={150} width={900} tailX={540} size={62} lines={[{text: 'তানিয়া? তুই এখানে কেন?', at: 35.32}, {text: 'বৃষ্টিতে ভিজে যাবি তো।', at: 37.76}]} />
      <Pop cx={880} y={700} at={37.8} float={8}><CloudRainIcon size={200} /></Pop>
    </>
  );
};

// ---------- S8: Tania apologises ----------
export const S8: React.FC = () => {
  const m = useMouth('tania');
  return (
    <>
      <Zoom a={1} b={1.05}>
        <StreetBG dark={0.55} />
        <Character who="tania" cx={540} foot={1868} size={1100} expr="cry" mouth={m} pose="hold" tremble />
        <Rain intensity={0.8} />
      </Zoom>
      <SpeechBubble left={90} top={150} width={900} tailX={540} size={60} lines={[{text: 'আপু, আমাকে মাফ করে দাও।', at: 39.72}, {text: 'আমি আর কখনো জামার জন্য বকবো না।', at: 42.54}]} />
      <Pop cx={880} y={690} at={43.64} float={6}>
        <div style={{position: 'relative', width: 200, height: 200}}>
          <DressIcon size={200} color="#4F8DF7" />
          <div style={{position: 'absolute', inset: 0}}><CrossX size={200} /></div>
        </div>
      </Pop>
    </>
  );
};

// ---------- S9: the hug ----------
const Hug: React.FC<{t: number; nExpr: 'happycry'; tExpr: 'cry' | 'happycry'; nMouth?: 0 | 1 | 2}> = ({t, nExpr, tExpr, nMouth = 0}) => {
  const hug = t >= 46.9;
  const ncx = L(t, [45.5, 47.0], [300, 400]);
  const tcx = L(t, [45.5, 47.0], [800, 650]);
  return (
    <>
      <Character who="tania" cx={tcx} foot={1700} size={900} expr={tExpr} pose={hug ? 'hugL' : 'down'} tilt={hug ? -8 : 0} tremble />
      <Character who="nusrat" cx={ncx} foot={1700} size={900} expr={nExpr} mouth={nMouth} pose={hug ? 'hugR' : 'down'} tilt={hug ? 8 : 0} />
    </>
  );
};
export const S9: React.FC = () => {
  const t = useT();
  return (
    <>
      <StreetBG dark={0.55} />
      <Crowd umb />
      <Hug t={t} nExpr="happycry" tExpr="cry" />
      <Rain intensity={0.8} />
      <Pop cx={540} y={640} at={47.3} until={50} float={10}><HeartIcon size={170} /></Pop>
      <Pop cx={360} y={500} at={51.0} float={10}><HeartIcon size={130} /></Pop>
      <Caption />
    </>
  );
};

// ---------- S10: "Pagli, ..." rain clears ----------
export const S10: React.FC = () => {
  const t = useT();
  const m = useMouth('nusrat');
  const arcs = ['#E94B4B', '#F29B38', '#FFD43B', '#3DBE6B', '#3B82F6', '#8E6BBF'];
  return (
    <>
      <StreetBG dark={L(t, [52.5, 56], [0.55, 0.1])} sun={L(t, [54.5, 56.5], [0, 1])} />
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, opacity: L(t, [55, 56.5], [0, 0.8])}}>
        {arcs.map((c, i) => <path key={i} d={`M${60 + i * 26},1250 A${480 - i * 26},${480 - i * 26} 0 0 1 ${1020 - i * 26},1250`} fill="none" stroke={c} strokeWidth={26} />)}
      </svg>
      <Crowd />
      <Character who="tania" cx={650} foot={1700} size={900} expr={t >= 55 ? 'happycry' : 'cry'} pose="hugL" tilt={-8} tremble={t < 54.5} />
      <Character who="nusrat" cx={400} foot={1700} size={900} expr="happycry" mouth={m} pose="hugR" tilt={8} />
      <Rain intensity={L(t, [52.5, 56], [0.8, 0])} />
      <SpeechBubble left={60} top={160} width={960} tailX={400} size={60} lines={[{text: 'পাগলি,', at: 53.36}, {text: 'বোনের উপর কি কেউ রাগ করে থাকে?', at: 54.5}]} />
    </>
  );
};

// ---------- S11: the message (motion graphics) ----------
export const S11: React.FC = () => {
  const t = useT();
  const pulse = 1 + 0.06 * Math.sin(t * 7);
  const NoCard: React.FC<{at: number; name: string; children: React.ReactNode}> = ({at, name, children}) => (
    <Card w={440} h={470}>
      <div style={{fontSize: 56}}>{name}</div>
      <div style={{position: 'relative', width: 200, height: 200}}>
        {children}
        {t >= at && <div style={{position: 'absolute', inset: 0}}><CrossX size={200} /></div>}
      </div>
      <div style={{fontSize: 48, color: '#C62828'}}>জিনিস চায় না</div>
    </Card>
  );
  return (
    <>
      <MGBG />
      <Pop cx={540} y={120} at={57.0}>
        <div style={{position: 'relative', width: 340, height: 430}}>
          <ParentsFrame x={170} y={215} w={340} h={430} glow={0.5} />
        </div>
      </Pop>
      <Pop cx={300} y={640} at={57.5}><NoCard at={58.0} name="মা-বাবা"><DressIcon size={200} /></NoCard></Pop>
      <Pop cx={780} y={640} at={58.64}><NoCard at={59.3} name="বোনও"><WalletIcon size={200} /></NoCard></Pop>
      <Pop cx={540} y={1190} at={60.22}><div style={{transform: `scale(${pulse})`}}><HeartIcon size={380} /></div></Pop>
      <Pop cx={540} y={1640} at={61.22}>
        <Card w={820} h={150} bg="#FFE3EA"><div style={{fontSize: 90, color: '#C2185B'}}>একটু ভালোবাসা</div></Card>
      </Pop>
    </>
  );
};

// ---------- S12: follow CTA ----------
export const S12: React.FC = () => {
  const t = useT();
  const done = t >= 65.6;
  const pulse = 1 + 0.05 * Math.sin(t * 9);
  return (
    <>
      <MGBG />
      <Pop cx={540} y={150} at={63.2}><Card w={900} h={170}><div style={{fontSize: 74}}>গল্পটা ভালো লেগেছে?</div></Card></Pop>
      <Pop cx={540} y={470} at={64.92}>
        <div style={{transform: `scale(${done ? 1 : pulse})`}}>
          <Pill bg={done ? '#3DBE6B' : '#E94B4B'} size={92}>
            {done ? <CheckIcon size={80} /> : <PlusIcon size={70} />}
            {done ? 'ফলো করা হয়েছে' : 'ফলো'}
          </Pill>
        </div>
      </Pop>
      <Pop cx={540} y={760} at={66.06}>
        <div style={{transform: 'rotate(-4deg)'}}><Pill bg="#FFD43B" color={INK} size={110}>পর্ব ৩ আসছে</Pill></div>
      </Pop>
      <Character who="nusrat" cx={300} foot={1800} size={700} expr="smile" />
      <Character who="tania" cx={780} foot={1800} size={700} expr="smile" bounce />
      <Pop cx={540} y={1180} at={66.6} float={10}><HeartIcon size={150} /></Pop>
    </>
  );
};
