import React, {createContext, useContext} from 'react';
import {Sequence, useCurrentFrame, useVideoConfig, spring, interpolate} from 'remotion';
import voice from './data/voice.json';
import {CAPTIONS} from './data/captions';
import {FONT, INK, FPS, TOTAL} from './config';

// ---------- timing ----------
const Ctx = createContext(0);

const Fade: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', inset: 0, overflow: 'hidden', opacity: interpolate(f, [0, 6], [0, 1], {extrapolateRight: 'clamp'})}}>
      {children}
    </div>
  );
};

/** Full-screen scene. from/to are global seconds. */
export const Scene: React.FC<{from: number; to: number; children: React.ReactNode}> = ({from, to, children}) => {
  const f0 = Math.round(from * FPS);
  const f1 = Math.min(TOTAL, Math.round(to * FPS));
  return (
    <Sequence from={f0} durationInFrames={f1 - f0}>
      <Ctx.Provider value={f0}>
        <Fade>{children}</Fade>
      </Ctx.Provider>
    </Sequence>
  );
};

/** Global time in seconds (audio time). */
export const useT = () => {
  const f = useCurrentFrame();
  return (useContext(Ctx) + f) / FPS;
};

// ---------- lip sync (from JSON word timings) ----------
type Who = 'narrator' | 'tania' | 'nusrat';
const SPK: Record<Who, string> = {narrator: 'speaker_0', nusrat: 'speaker_1', tania: 'speaker_2'};
const WORDS = voice.segments.flatMap((s) =>
  s.words.filter((w) => w.text.trim()).map((w) => ({spk: s.speaker.id, s: w.start_time, e: w.end_time})),
);
export const useMouth = (who: Who): 0 | 1 | 2 => {
  const t = useT();
  const w = WORDS.find((x) => x.spk === SPK[who] && t >= x.s && t < x.e + 0.04);
  if (!w) return 0;
  return (1 + (Math.floor((t - w.s) * 10) % 2)) as 1 | 2;
};

// ---------- pop-in wrapper (centered at cx, top y) ----------
export const Pop: React.FC<{cx: number; y: number; at: number; until?: number; float?: number; children: React.ReactNode}> = ({cx, y, at, until, float = 0, children}) => {
  const t = useT();
  const {fps} = useVideoConfig();
  const f = useCurrentFrame();
  if (t < at || (until !== undefined && t > until + 0.3)) return null;
  const s = spring({frame: Math.max(0, Math.round((t - at) * fps)), fps, config: {damping: 11, stiffness: 150}});
  const out = until !== undefined ? interpolate(t, [until, until + 0.25], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 1;
  const bob = float ? Math.sin(f / 12) * float : 0;
  return (
    <div style={{position: 'absolute', left: cx - 700, width: 1400, top: y, display: 'flex', justifyContent: 'center', pointerEvents: 'none'}}>
      <div style={{transform: `translateY(${bob}px) scale(${s})`, opacity: out}}>{children}</div>
    </div>
  );
};

export const Pill: React.FC<{bg: string; color?: string; size?: number; children: React.ReactNode}> = ({bg, color = '#fff', size = 48, children}) => (
  <div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '10px 34px', borderRadius: 60, background: bg, color, fontFamily: FONT, fontWeight: 700, fontSize: size, border: `4px solid ${INK}`, boxShadow: '0 6px 0 rgba(0,0,0,.25)', whiteSpace: 'nowrap'}}>
    {children}
  </div>
);

export const Card: React.FC<{w: number; h?: number; bg?: string; children: React.ReactNode}> = ({w, h, bg = '#fff', children}) => (
  <div style={{width: w, height: h, background: bg, border: `5px solid ${INK}`, borderRadius: 44, boxShadow: '0 12px 0 rgba(0,0,0,.18)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14, padding: 24, fontFamily: FONT, fontWeight: 700, color: INK, boxSizing: 'border-box', textAlign: 'center'}}>
    {children}
  </div>
);

// ---------- speech bubble ----------
export const SpeechBubble: React.FC<{left: number; top: number; width: number; tailX: number; lines: {text: string; at: number}[]; size?: number}> = ({left, top, width, tailX, lines, size = 58}) => {
  const t = useT();
  const {fps} = useVideoConfig();
  const at = lines[0].at;
  if (t < at) return null;
  const s = spring({frame: Math.max(0, Math.round((t - at) * fps)), fps, config: {damping: 13, stiffness: 170}});
  return (
    <div style={{position: 'absolute', left, top, width, transform: `scale(${s})`, transformOrigin: `${tailX - left}px 100%`}}>
      <div style={{background: '#fff', border: `5px solid ${INK}`, borderRadius: 46, padding: '30px 44px', boxShadow: '0 10px 0 rgba(0,0,0,.18)', fontFamily: FONT, fontWeight: 600, fontSize: size, lineHeight: 1.3, color: INK, textAlign: 'center'}}>
        {lines.map((l, i) => {
          const p = Math.min(1, Math.max(0, (t - l.at) / 0.2));
          return (
            <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 14}px)`}}>
              {l.text}
            </div>
          );
        })}
      </div>
      <div style={{position: 'absolute', left: tailX - left - 26, top: '100%', marginTop: -30, width: 52, height: 52, background: '#fff', borderRight: `5px solid ${INK}`, borderBottom: `5px solid ${INK}`, transform: 'rotate(45deg)'}} />
    </div>
  );
};

// ---------- overlay caption (only used in scenes without bubbles/cards) ----------
export const Caption: React.FC = () => {
  const t = useT();
  const c = CAPTIONS.find((x) => t >= x.s && t < x.e);
  if (!c) return null;
  const p = Math.min(1, (t - c.s) / 0.18);
  const q = Math.min(1, (c.e - t) / 0.08);
  const parts = c.t.split('*');
  return (
    <div style={{position: 'absolute', left: 30, right: 30, bottom: 200, display: 'flex', justifyContent: 'center', opacity: Math.min(p, q), transform: `translateY(${(1 - p) * 36}px)`}}>
      <div style={{padding: '16px 40px', borderRadius: 42, background: 'rgba(24,20,34,.66)', color: '#fff', fontFamily: FONT, fontWeight: 600, fontSize: 62, whiteSpace: 'nowrap'}}>
        {parts.map((x, i) => (i % 2 ? <span key={i} style={{color: '#FFD43B', fontWeight: 700}}>{x}</span> : <span key={i}>{x}</span>))}
      </div>
    </div>
  );
};

// ---------- camera helpers ----------
export const Shake: React.FC<{from: number; to: number; amp: number; children: React.ReactNode}> = ({from, to, amp, children}) => {
  const t = useT();
  const f = useCurrentFrame();
  const a = t >= from && t <= to ? amp : 0;
  return <div style={{position: 'absolute', inset: 0, transform: `translate(${Math.sin(f * 5.1) * a}px,${Math.cos(f * 6.7) * a}px) rotate(${Math.sin(f * 4.3) * a * 0.04}deg)`}}>{children}</div>;
};

export const Zoom: React.FC<{a: number; b: number; origin?: string; children: React.ReactNode}> = ({a, b, origin = '50% 60%', children}) => {
  const f = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  return <div style={{position: 'absolute', inset: 0, transformOrigin: origin, transform: `scale(${interpolate(f, [0, durationInFrames], [a, b])})`}}>{children}</div>;
};

export const Fill: React.FC<{style?: React.CSSProperties; children?: React.ReactNode}> = ({style, children}) => (
  <div style={{position: 'absolute', inset: 0, ...style}}>{children}</div>
);
