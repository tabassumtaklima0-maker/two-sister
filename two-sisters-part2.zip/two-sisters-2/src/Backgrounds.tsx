import React from 'react';
import {useCurrentFrame} from 'remotion';
import {INK} from './config';
import {Fill} from './ui';

export const Vignette: React.FC<{a?: number}> = ({a = 0.28}) => (
  <Fill style={{background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,${a}) 100%)`}} />
);

/** Clean motion-graphics background (edge to edge). */
export const MGBG: React.FC = () => (
  <>
    <Fill style={{background: 'radial-gradient(circle at 50% 38%, #FFF7E6 0%, #F6DFB9 100%)'}} />
    <Vignette a={0.18} />
  </>
);

export const VillageBG: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Fill>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920">
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#FF9A62" /><stop offset="0.55" stopColor="#FFD08A" /><stop offset="1" stopColor="#FFF0C8" />
          </linearGradient>
        </defs>
        <rect width={1080} height={1920} fill="url(#sky)" />
        <circle cx={770} cy={780 - f * 1.2} r={150} fill="#FFF3B0" opacity={0.95} />
        {[0, 1, 2].map((i) => (
          <g key={i} transform={`translate(${((f * (0.5 + i * 0.2) + i * 380) % 1500) - 250},${300 + i * 150})`} opacity={0.85}>
            <ellipse cx={0} cy={0} rx={110} ry={34} fill="#fff" /><ellipse cx={60} cy={-22} rx={70} ry={30} fill="#fff" /><ellipse cx={-50} cy={-14} rx={60} ry={26} fill="#fff" />
          </g>
        ))}
        <path d="M0,1180 Q200,1030 420,1150 T860,1110 T1080,1170 V1920 H0Z" fill="#78B86C" stroke={INK} strokeWidth={3} />
        <path d="M0,1330 Q300,1260 600,1330 T1080,1300 V1920 H0Z" fill="#5AA55A" stroke={INK} strokeWidth={3} />
        {[0, 1, 2, 3, 4].map((i) => (
          <path key={i} d={`M0,${1420 + i * 90} Q540,${1390 + i * 90} 1080,${1420 + i * 90}`} stroke="#3F8A47" strokeWidth={6} fill="none" opacity={0.6} />
        ))}
        {/* hut */}
        <g transform="translate(150,1040)">
          <rect x={0} y={60} width={220} height={150} fill="#E9C88F" stroke={INK} strokeWidth={4} />
          <path d="M-25,70 L110,-30 L245,70Z" fill="#B5733B" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
          <rect x={85} y={110} width={50} height={100} fill="#7A4B2A" stroke={INK} strokeWidth={4} />
        </g>
        {/* palm trees */}
        {[820, 960].map((x, i) => (
          <g key={x} transform={`translate(${x},${1090 + i * 50})`}>
            <path d="M0,260 Q-15,130 10,0" stroke="#8A5A3C" strokeWidth={22} fill="none" strokeLinecap="round" />
            {[-70, -30, 20, 60].map((a, k) => (
              <path key={k} d={`M10,0 Q${a * 2},-60 ${a * 3},${20 + Math.abs(a)}`} stroke="#2F7D3C" strokeWidth={26} fill="none" strokeLinecap="round" />
            ))}
          </g>
        ))}
      </svg>
      <Vignette a={0.22} />
    </Fill>
  );
};

export const RoomBG: React.FC<{mode?: 'day' | 'night' | 'morning'; window?: boolean; shelf?: boolean}> = ({mode = 'day', window: win = false, shelf = false}) => {
  const night = mode === 'night';
  const wall = night ? '#252B55' : mode === 'morning' ? '#FBE6C2' : '#F4DDB8';
  const dado = night ? '#1D2347' : mode === 'morning' ? '#EDCB98' : '#E3BE88';
  const floor = night ? '#3A2E2A' : '#B98A5A';
  return (
    <Fill>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920">
        <defs>
          <linearGradient id="msky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFD9A0" /><stop offset="1" stopColor="#FFF2CC" /></linearGradient>
        </defs>
        <rect width={1080} height={1300} fill={wall} />
        <rect y={980} width={1080} height={320} fill={dado} />
        <rect y={976} width={1080} height={8} fill={INK} opacity={0.25} />
        <rect y={1300} width={1080} height={620} fill={floor} />
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <line key={i} x1={0} x2={1080} y1={1300 + (i + 1) * (i + 1) * 12} y2={1300 + (i + 1) * (i + 1) * 12} stroke={INK} opacity={0.14} strokeWidth={4} />
        ))}
        <rect y={1284} width={1080} height={18} fill={INK} opacity={0.22} />
        {win && (
          <g>
            {mode === 'morning' && <path d="M100,330 L380,330 L760,1300 L300,1300Z" fill="#FFF3B0" opacity={0.2} />}
            <rect x={90} y={300} width={300} height={420} fill={night ? '#12183A' : mode === 'morning' ? 'url(#msky)' : '#BFE7F7'} stroke="#7A4B2A" strokeWidth={12} />
            {night && (
              <>
                <circle cx={250} cy={440} r={46} fill="#FFF1B8" />
                {[[150, 380], [320, 360], [180, 600], [330, 560], [120, 500]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={4} fill="#fff" />)}
              </>
            )}
            {mode === 'morning' && <circle cx={300} cy={420} r={52} fill="#FFD43B" />}
            {mode === 'day' && <ellipse cx={230} cy={450} rx={80} ry={28} fill="#fff" />}
            <path d="M240,300 V720 M90,510 H390" stroke="#7A4B2A" strokeWidth={10} />
            <rect x={70} y={716} width={340} height={22} fill="#7A4B2A" stroke={INK} strokeWidth={3} />
            <path d="M80,300 Q130,520 80,720 L60,720 L60,300Z M400,300 Q350,520 400,720 L420,720 L420,300Z" fill={night ? '#6B3B5E' : '#E58BA0'} stroke={INK} strokeWidth={3} />
          </g>
        )}
        {shelf && (
          <g>
            <rect x={740} y={860} width={300} height={18} fill="#7A4B2A" stroke={INK} strokeWidth={3} />
            <path d="M820,860 L810,790 H900 L890,860Z" fill="#C9683E" stroke={INK} strokeWidth={3} />
            {[[835, 740], [865, 720], [895, 745]].map(([x, y], i) => <ellipse key={i} cx={x} cy={y} rx={24} ry={42} fill="#3F9A4B" stroke={INK} strokeWidth={3} transform={`rotate(${(i - 1) * 22} ${x} ${y + 40})`} />)}
            <rect x={950} y={810} width={50} height={50} fill="#6C8EBF" stroke={INK} strokeWidth={3} />
          </g>
        )}
      </svg>
      <Vignette a={night ? 0.4 : 0.25} />
    </Fill>
  );
};

export const ParentsFrame: React.FC<{x: number; y: number; w: number; h: number; glow?: number}> = ({x, y, w, h, glow = 0}) => (
  <div style={{position: 'absolute', left: x - w / 2, top: y - h / 2, width: w, height: h, boxShadow: glow ? `0 0 ${glow * 90}px ${glow * 34}px rgba(255,214,120,.75)` : undefined, borderRadius: 14}}>
    <svg width={w} height={h} viewBox="0 0 300 380">
      <rect x={2} y={2} width={296} height={376} rx={12} fill="#7A4B2A" stroke={INK} strokeWidth={4} />
      <rect x={18} y={18} width={264} height={344} fill="#D8C4A0" stroke={INK} strokeWidth={3} />
      {/* father */}
      <path d="M36,362 V282 Q36,240 90,235 Q144,240 144,282 V362Z" fill="#EDEDED" stroke={INK} strokeWidth={3} />
      <path d="M90,238 V300" stroke={INK} strokeWidth={3} />
      <circle cx={90} cy={190} r={38} fill="#D9A877" stroke={INK} strokeWidth={3} />
      <path d="M54,185 Q56,150 90,148 Q124,150 126,185 Q110,165 90,166 Q70,165 54,185Z" fill="#2A1A16" />
      <circle cx={78} cy={192} r={3.5} fill={INK} /><circle cx={102} cy={192} r={3.5} fill={INK} />
      <path d="M78,210 Q90,216 102,210" stroke={INK} strokeWidth={3} fill="none" strokeLinecap="round" />
      {/* mother */}
      <path d="M160,362 V284 Q160,244 212,238 Q264,244 264,284 V362Z" fill="#B5323C" stroke={INK} strokeWidth={3} />
      <path d="M180,250 Q230,300 262,290" stroke="#F2D98C" strokeWidth={6} fill="none" />
      <circle cx={212} cy={192} r={36} fill="#D9A877" stroke={INK} strokeWidth={3} />
      <circle cx={212} cy={146} r={18} fill="#2A1A16" stroke={INK} strokeWidth={3} />
      <path d="M176,190 Q178,150 212,150 Q246,152 248,190 Q232,166 212,168 Q192,166 176,190Z" fill="#2A1A16" />
      <circle cx={200} cy={192} r={3.5} fill={INK} /><circle cx={224} cy={192} r={3.5} fill={INK} />
      <circle cx={212} cy={178} r={3} fill="#D33" />
      <path d="M200,208 Q212,214 224,208" stroke={INK} strokeWidth={3} fill="none" strokeLinecap="round" />
      <path d="M244,18 L282,18 L282,56Z" fill="#111" />
    </svg>
  </div>
);

export const Table: React.FC<{cx: number; top: number; w: number; foot: number}> = ({cx, top, w, foot}) => (
  <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
    <rect x={cx - w / 2 + 30} y={top} width={36} height={foot - top} fill="#7A4B2A" stroke={INK} strokeWidth={4} />
    <rect x={cx + w / 2 - 66} y={top} width={36} height={foot - top} fill="#7A4B2A" stroke={INK} strokeWidth={4} />
    <rect x={cx - w / 2} y={top} width={w} height={36} rx={8} fill="#A06A36" stroke={INK} strokeWidth={4} />
  </svg>
);

export const SleepingTania: React.FC<{x: number; y: number}> = ({x, y}) => (
  <svg width={420} height={260} viewBox="0 0 420 260" style={{position: 'absolute', left: x, top: y}}>
    <rect x={0} y={170} width={420} height={70} rx={20} fill="#8DA6D8" stroke={INK} strokeWidth={4} />
    <ellipse cx={80} cy={160} rx={70} ry={30} fill="#fff" stroke={INK} strokeWidth={4} />
    <circle cx={50} cy={92} r={24} fill="#2A1A16" stroke={INK} strokeWidth={3} /><circle cx={112} cy={92} r={24} fill="#2A1A16" stroke={INK} strokeWidth={3} />
    <circle cx={80} cy={128} r={50} fill="#F2C69E" stroke={INK} strokeWidth={4} />
    <path d="M32,122 Q80,70 128,122 Q80,100 32,122Z" fill="#2A1A16" />
    <path d="M58,132 Q66,140 74,132 M88,132 Q96,140 104,132" stroke={INK} strokeWidth={3.5} fill="none" strokeLinecap="round" />
    <path d="M72,152 Q80,157 88,152" stroke={INK} strokeWidth={3.5} fill="none" strokeLinecap="round" />
    <path d="M120,110 Q250,90 400,120 V215 H120Z" fill="#E26A8D" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
    <path d="M180,125 V210 M260,118 V212 M340,120 V212" stroke="#C84B70" strokeWidth={4} />
  </svg>
);

/** Bazaar street. dark: 0..1 (rain-cloud darkness), sun: 0..1 (clearing glow). */
export const StreetBG: React.FC<{dark?: number; sun?: number}> = ({dark = 0, sun = 0}) => (
  <Fill>
    <svg width={1080} height={1920} viewBox="0 0 1080 1920">
      <defs>
        <linearGradient id="csky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#9DB7CF" /><stop offset="1" stopColor="#E3EEF4" /></linearGradient>
      </defs>
      <rect width={1080} height={1920} fill="url(#csky)" />
      {[[160, 300, 1], [620, 220, 1.3], [900, 420, 0.9]].map(([x, y, k], i) => (
        <g key={i} transform={`translate(${x},${y}) scale(${k})`} opacity={0.9}>
          <ellipse cx={0} cy={0} rx={130} ry={40} fill="#F4F7FA" /><ellipse cx={70} cy={-26} rx={80} ry={36} fill="#F4F7FA" /><ellipse cx={-60} cy={-18} rx={70} ry={30} fill="#F4F7FA" />
        </g>
      ))}
      {/* shop row */}
      {[0, 1, 2].map((i) => (
        <g key={i} transform={`translate(${i * 370 - 20},980)`}>
          <rect x={0} y={60} width={350} height={300} fill={['#F3D9A4', '#D9E8C9', '#F2C9C0'][i]} stroke={INK} strokeWidth={4} />
          <rect x={30} y={190} width={290} height={170} fill="#5B4636" stroke={INK} strokeWidth={4} />
          <path d={`M-10,60 L20,0 H330 L360,60Z`} fill={['#E94B4B', '#2E8F8C', '#F29B38'][i]} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
          {[0, 1, 2, 3, 4].map((k) => <path key={k} d={`M${-10 + k * 74},60 a37,24 0 0 0 74,0`} fill={k % 2 ? '#fff' : ['#E94B4B', '#2E8F8C', '#F29B38'][i]} stroke={INK} strokeWidth={4} />)}
          <rect x={90} y={215} width={170} height={36} rx={8} fill="#FFE9A8" /><rect x={90} y={270} width={170} height={36} rx={8} fill="#FFB4A2" />
        </g>
      ))}
      {/* footpath + road */}
      <rect y={1340} width={1080} height={120} fill="#B9B3A8" stroke={INK} strokeWidth={4} />
      <rect y={1460} width={1080} height={460} fill="#6E7378" />
      {[0, 1, 2, 3].map((i) => <rect key={i} x={40 + i * 280} y={1700} width={150} height={16} rx={8} fill="#F0E9C8" opacity={0.8} />)}
      {/* lamp post */}
      <rect x={990} y={800} width={22} height={560} fill="#444" stroke={INK} strokeWidth={3} />
      <circle cx={1001} cy={790} r={34} fill="#FFE9A8" stroke={INK} strokeWidth={4} />
    </svg>
    <Fill style={{background: `rgba(30,40,70,${dark * 0.55})`}} />
    <Fill style={{background: 'radial-gradient(circle at 30% 12%, rgba(255,220,130,.9) 0%, rgba(255,220,130,0) 55%)', opacity: sun}} />
    <Vignette a={0.25} />
  </Fill>
);

export const Rain: React.FC<{intensity: number}> = ({intensity}) => {
  const f = useCurrentFrame();
  const n = Math.floor(90 * intensity);
  return (
    <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
      {Array.from({length: n}).map((_, i) => {
        const x = ((i * 137) % 1160) - 40;
        const y = ((f * (26 + (i % 5) * 4) + i * 263) % 2100) - 120;
        return <line key={i} x1={x} y1={y} x2={x - 10} y2={y + 56} stroke="#DCEBFF" strokeWidth={4} strokeLinecap="round" opacity={0.65} />;
      })}
    </svg>
  );
};

/** Simple nameless crowd extra (same flat style). */
export const Extra: React.FC<{cx: number; foot: number; size?: number; color?: string; hair?: string; skin?: string; walk?: number; umbrella?: string}> = ({cx, foot, size = 520, color = '#8E6BBF', hair = '#222', skin = '#E3B58A', walk = 0.25, umbrella}) => {
  const f = useCurrentFrame();
  const sw = Math.sin(f * walk);
  const w = size / 2;
  return (
    <svg width={w} height={size} viewBox="0 0 200 400" style={{position: 'absolute', left: cx - w / 2, top: foot - size, overflow: 'visible'}}>
      <g transform={`translate(0,${Math.abs(sw) * -5})`}>
        <g transform={`rotate(${sw * 14} 80 250)`}><rect x={64} y={250} width={34} height={130} rx={16} fill="#3B4A6B" stroke={INK} strokeWidth={3} /></g>
        <g transform={`rotate(${-sw * 14} 120 250)`}><rect x={102} y={250} width={34} height={130} rx={16} fill="#3B4A6B" stroke={INK} strokeWidth={3} /></g>
        <rect x={50} y={110} width={100} height={170} rx={34} fill={color} stroke={INK} strokeWidth={3} />
        <rect x={34} y={120} width={26} height={110} rx={13} fill={color} stroke={INK} strokeWidth={3} transform={`rotate(${sw * 12} 47 125)`} />
        <rect x={140} y={120} width={26} height={110} rx={13} fill={color} stroke={INK} strokeWidth={3} transform={`rotate(${-sw * 12} 153 125)`} />
        <circle cx={100} cy={64} r={42} fill={skin} stroke={INK} strokeWidth={3} />
        <path d="M58,62 Q60,18 100,18 Q140,18 142,62 Q124,40 100,42 Q76,40 58,62Z" fill={hair} stroke={INK} strokeWidth={3} />
        <circle cx={86} cy={68} r={4} fill={INK} /><circle cx={114} cy={68} r={4} fill={INK} />
        <path d="M88,84 Q100,92 112,84" stroke={INK} strokeWidth={3} fill="none" strokeLinecap="round" />
        {umbrella && (
          <g>
            <path d="M100,-20 V120" stroke={INK} strokeWidth={5} />
            <path d="M-20,20 Q100,-120 220,20 Q190,0 160,20 Q130,0 100,20 Q70,0 40,20 Q10,0 -20,20Z" fill={umbrella} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
          </g>
        )}
      </g>
    </svg>
  );
};

export const Door: React.FC<{x: number; y: number}> = ({x, y}) => (
  <svg width={300} height={560} viewBox="0 0 300 560" style={{position: 'absolute', left: x, top: y}}>
    <rect x={10} y={10} width={280} height={540} fill="#7A4B2A" stroke={INK} strokeWidth={5} />
    <rect x={40} y={40} width={220} height={510} fill="#FFF3C4" />
    <path d="M40,40 L10,10 M260,40 L290,10" stroke={INK} strokeWidth={4} />
  </svg>
);
